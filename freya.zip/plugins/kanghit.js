import axios from 'axios'

async function apivisit() {
axios.get(`https://status.pnggilajacn.my.id`);
axios.get(`https://status.pnggilajacn.my.id`);
}
export { 
    apivisit 
}
